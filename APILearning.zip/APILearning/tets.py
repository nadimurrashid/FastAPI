def twoSum(nums, target):
    """
    :type nums: List[int]
    :type target: int
    :rtype: List[int]
    """
    h = {}
    for i, num in enumerate(nums):
        n = target - num
        if n not in h:
            h[num] = i
        else:
            return [h[n], i]

c = [1,2,3,4,5]
target = 8
d = twoSum(c,target)
print(d)

t = {}
d = [2,3,4]
t[d]=0
print(t)