from fastapi import FastAPI, Body, Response, status, HTTPException , Depends
from typing import Union, Optional
from pydantic import BaseModel
from random import randrange
import psycopg2
from psycopg2.extras import RealDictCursor
import time

from . import models
from .database import engine, SessionLocal, get_db
from sqlalchemy.orm import Session

models.Base.metadata.create_all(bind=engine)

app = FastAPI()





class Post(BaseModel):
    title: str
    content: str
    published: bool = True
    # rating: Optional[int] = None


while True:
    try:
        conn = psycopg2.connect(host='localhost', database='apitest', user='postgres', password='postgres',
                                cursor_factory=RealDictCursor)
        cursor = conn.cursor()



        print("Database connection is successfull")
        break

    except Exception as error:
        print("Connecting to database fail")
        print("Error: ", error)
        time.sleep(2)

my_posts = []


def find_post(id):
    for p in my_posts:
        if p["id"] == id:
            return p


def find_index_post(id):
    for i, p in enumerate(my_posts):
        if p['id'] == id:
            return i


@app.get("/")
def read_root():
    return {"message": "hello my api's"}

@app.get("/sqlalchemy")
def test_post(db: Session = Depends(get_db)):
    post = db.query(models.Post).all()
    return {"status": post}


@app.get("/posts")
def get_posts():
    cursor.execute(""" select * from "posts" """)
    posts = cursor.fetchall()
    return {"data": posts}




@app.post("/posts", status_code=status.HTTP_201_CREATED)
def create_posts(post: Post):
    # post_dict = post.dict()
    # post_dict['id'] = randrange(0, 100000)
    # my_posts.append(post_dict)
    cursor.execute(""" INSERT INTO posts (title,content,published) VALUES (%s,%s,%s) RETURNING * """,(post.title , post.content , post.published))
    new_post = cursor.fetchone()
    conn.commit()
    return {"data": new_post}


@app.get("/posts/latest")
def get_latest_post():
    pos = my_posts[len(my_posts) - 1]
    return {"detail": pos}


@app.get("/posts/{id}")
def get_post(id: int, response: Response):
    # post = find_post(int(id))
    cursor.execute(""" SELECT * FROM posts WHERE id = %s """,(str(id)))
    post = cursor.fetchone()
    if not post:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"post with {id} was not found")
        # response.status_code = status.HTTP_404_NOT_FOUND
        # return {"message" : f"post with {id} was not found"}
    return {"post_datail": post}


@app.delete("/posts/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_post(id: int):
    # index = find_index_post(id)
    cursor.execute(""" DELETE FROM posts WHERE id = %s RETURNING * """, (str(id),))
    deleted_post = cursor.fetchone()
    conn.commit()
    if deleted_post == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"post with id: {id} is not being found")
    # my_posts.pop(index)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.put("/posts/{id}")
def update_post(id: int, post: Post):
    # index = find_index_post(id)
    cursor.execute(""" UPDATE posts SET title = %s , content = %s , published = %s WHERE id = %s RETURNING * """, ( post.title , post.content , post.published,str(id)))
    post_updated = cursor.fetchone()
    conn.commit()
    if post_updated == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"post with id: {id} is not being found")
    # print(post)
    # post_dict = post.dict()
    # print(post_dict)
    # post_dict["id"] = id
    # my_posts[index] = post_dict
    return {"data": post_updated}
